var Paymentech = require("ti.passbook.paymentech");


Paymentech.createGateway();
